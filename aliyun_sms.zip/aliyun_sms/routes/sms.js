var express = require('express');
var router = express.Router();
/**
 * 云通信基础能力业务短信发送、查询详情以及消费消息示例，供参考。
 * Created on 2017-07-31
 */
const SMSClient = require('@alicloud/sms-sdk')

// ACCESS_KEY_ID/ACCESS_KEY_SECRET 根据实际申请的账号信息进行替换
const accessKeyId = 'LTAI4G4oj1o7KsQpWPqg976N'
const secretAccessKey = 'VuoWpGaOpo8SBzwke8UiEexqnvM07K'

//初始化sms_client
let smsClient = new SMSClient({accessKeyId, secretAccessKey})


router.get('/', function(req, res, next) {
    const phone_number = req.query.phonenumber;
    const fastreg = req.query.fastreg;
    //发送短信
    smsClient.sendSMS({
        PhoneNumbers: phone_number,
        SignName: '伟普教育',
        TemplateCode: 'SMS_198667060',
        TemplateParam: `{"fastreg":"${fastreg}"}`
    }).then(function (res1) {
        let {Code}=res1
        if (Code === 'OK') {
            //处理返回参数
            res.send(res1);
        }
    }, function (err) {
        res.send(err);
    })
});

module.exports = router;